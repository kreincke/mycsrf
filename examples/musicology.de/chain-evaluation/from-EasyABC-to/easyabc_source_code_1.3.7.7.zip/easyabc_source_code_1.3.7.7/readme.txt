EasyABC - ABC editor by Nils Liberg
License: GNU Public License V2

Download and install:
   wxPython (http://www.wxpython.org/download.php)
   Python Midi Package (http://www.mxm.dk/products/public/pythonmidi)
   
Run the program by typing this on the command line:
   python easy_abc.py